MBS Nova Studio - press fact sheet

Studio: MBS Nova Studio (MBS Global Insaat Danismanlik Sanayi ve Ticaret Ltd. Sti.), Turkiye
What we make: mobile games and everyday apps for Android and iOS (Google Play now, iOS coming soon)
Website: https://mbsnovastudio.com | Press contact: info@mbsnovastudio.com | Social: @mbsnovastudio

About: MBS Nova Studio is an independent mobile studio making delightful games and useful everyday apps. We're always working on something new, each one for Android and iOS, and we hand-tune every detail so each product feels simple, fast and fun.

Jewelia - a relaxing royal match-3 jewel puzzle with hand-tuned levels that plays offline. Free (ads, optional in-app purchases). 7 languages (EN, TR, DE, ES, FR, IT, PT-BR).
https://mbsnovastudio.com/jewelia/ | https://play.google.com/store/apps/details?id=com.mbsgames.jewelia

Jarlings - a cozy puzzle game: guide tiny glass-jar friends home in the right order and restore cozy havens. Free (ads, optional in-app purchases). 7 languages (EN, TR, DE, ES, FR, IT, PT-BR).
https://mbsnovastudio.com/jarlings/ | https://play.google.com/store/apps/details?id=com.mbsnovastudio.jarlings

MBS Kasa - personal finance app for budgets, bills and gold & currency savings that keeps your data encrypted on your device. 6 languages (TR, EN, ES, FR, HI, ZH); available in Turkiye for now. Free, optional ad-free Premium.
https://mbsnovastudio.com/kasa/ | https://play.google.com/store/apps/details?id=com.mbs.kasa

Logo use: please use the logos as provided; don't recolour, stretch or add effects, and leave clear space around them.
